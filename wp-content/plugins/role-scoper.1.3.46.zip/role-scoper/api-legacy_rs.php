<?php

function scoper_apply_legacy_hascap_flags() {

}

?>